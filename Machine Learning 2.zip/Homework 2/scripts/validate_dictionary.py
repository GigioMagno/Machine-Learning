import numpy as np
from train_classifier_nb import *
from extract_features import validation

estimate_train_accuracy = []
estimate_test_accuracy = []

for x in range(5):
	validation()
	data = np.loadtxt("validation_train.txt.gz")
	X_valid_train = data[:, :-1]
	Y_valid_train = data[:, -1]

	data = np.loadtxt("validation_test.txt.gz")
	X_valid_test = data[:, :-1]
	Y_valid_test = data[:, -1]

	w,b = train_nb(X_valid_train, Y_valid_train)
	predictions = inference_nb(X_valid_train, w, b)
	accuracy = (predictions == Y_valid_train).mean()
	#print("Validation Training accuracy:", accuracy * 100)
	estimate_train_accuracy.append(accuracy*100)

	#Testing on validation data
	predictions = inference_nb(X_valid_test, w, b)
	accuracy = (predictions == Y_valid_test).mean()
	#print("Validation test accuracy:", accuracy * 100)
	estimate_test_accuracy.append(accuracy*100)


print("Estimated train accuracy: ", np.mean(estimate_train_accuracy))
print("Estimated test accuracy: ", np.mean(estimate_test_accuracy))