import numpy as np

def cross_entropy(P, Y):
    return (-Y * np.log(P) - (1 - Y) * np.log(1 - P)).mean()

def logreg_inference(X, w, b):
    z = X @ w + b
    p = 1 / (1 + np.exp(-z))
    return p

def logreg_train(X, Y, lambda_, lr, steps):
    m, n = X.shape
    w = np.zeros(n)
    b = 0
    accuracies = []
    losses = []
    for step in range(steps):
        P = logreg_inference(X, w, b)
        if step % 100 == 0:
            loss = cross_entropy(P, Y)
            prediction = (P > 0.5)
            accuracy = (prediction == Y).mean()
            accuracies.append(accuracy)
            losses.append(loss)
            print(step, loss, accuracy * 100)
        grad_w = ((P - Y) @ X) / m + 2 * lambda_ * w
        grad_b = (P - Y).mean()
        w -= lr * grad_w
        b -= lr * grad_b
    return w, b, accuracies, losses

#main

data = np.loadtxt("train.txt.gz")
X = data[:, :-1]
Y = data[:, -1]
w, b, _, _ = logreg_train(X, Y, 0, 0.03, 4500)
np.savez("logregr_weights.npz", w, b)