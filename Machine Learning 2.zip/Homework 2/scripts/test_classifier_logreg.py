#Logregr script

import numpy as np

def logreg_inference(X, w, b):
    z = X @ w + b
    p = 1 / (1 + np.exp(-z))
    return p

data = np.load("logregr_weights.npz")
w = data["arr_0"]
b = data["arr_1"]

data = np.loadtxt("test.txt.gz")
X = data[:, :-1]
Y = data[:, -1]

P = logreg_inference(X, w, b)
predictions = (P > 0.5)
accuracy = (Y == predictions).mean()
print("Test accuracy:", accuracy * 100)
