import numpy as np

def inference_nb(X, w, b):
    score = X @ w + b
    return (score > 0).astype(int)

#main


data = np.loadtxt("test.txt.gz")
X = data[:, :-1]
Y = data[:, -1]

data1 = np.load("model_nb.npz")
w = data1["arr_0"]
b = data1["arr_1"]
predictions = inference_nb(X, w, b)
accuracy = (predictions == Y).mean()

print("Test accuracy:", accuracy * 100)

f = open("vocabulary.txt")
voc = f.read().split()
f.close()

#Most negative words
indices = w.argsort()
print("NEGATIVE WORDS")
for i in indices[:20]:
    print(voc[i], w[i])
#Most positive words
print()
print("POSITIVE WORDS")
for i in indices[-20:]:
    print(voc[i], w[i])

#Errors in documents
err_docs = (X @ w + b)[Y != predictions]
indexes = err_docs.argsort()
err_w = (X * w + b)[Y != predictions]
idx = err_w[i].argsort()

print("false positives errors")
for i in indexes[-5:]:  
    print("Doc: ", i, "Score: ", err_docs[i], "\nwords with the most positive weights")
    for j in idx[-5:]:
        print("\t", voc[j])

print("\n\nfalse negatives errors")
for i in indexes[:5]:
    print("Doc: ", i, "Score: ", err_docs[i], "\nwords with the most negative weights")
    for j in idx[:5]:
        print("\t", voc[j])
