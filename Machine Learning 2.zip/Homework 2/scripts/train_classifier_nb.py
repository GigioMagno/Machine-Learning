import numpy as np


def train_nb(X, Y):

    pos_p = X[Y == 1, :].sum(0) + 1  
    pos_p = pos_p / pos_p.sum()      
    neg_p = X[Y == 0, :].sum(0) + 1
    neg_p = neg_p / neg_p.sum()      
    w = np.log(pos_p) - np.log(neg_p)
    pos_prior = Y.mean()
    neg_prior = 1 - pos_prior
    b = np.log(pos_prior) - np.log(neg_prior)
    return w, b


def inference_nb(X, w, b):
    score = X @ w + b
    # print(score)
    return (score > 0).astype(int)


data = np.loadtxt("train.txt.gz")
X = data[:, :-1]
Y = data[:, -1]
w, b = train_nb(X, Y)
predictions = inference_nb(X, w, b)
accuracy = (predictions == Y).mean()
print("Training accuracy:", accuracy * 100)
np.savez("model_nb.npz", w, b)