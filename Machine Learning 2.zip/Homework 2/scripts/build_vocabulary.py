import collections as clt
import os
from porter import stem

def remove_punctuation(text):
    punct = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"
    for p in punct:
        text = text.replace(p, " ")
    return text

#   This variant of the function removes the stopwords from the vocabulary
#
# def read_document(file) :
#     f = open(file, encoding="utf-8")
#     f2 = open("aclImdb/stopwords.txt")
#     stop = f2.read().split()
#     text = f.read()
#     f.close()
#     words = []
#     text = text.lower()
#     text = remove_punctuation(text)
#     for word in text.split():
#         if len(word) >2 and word not in stop:
#             words.append(word)
#     return words
#
#   This variant of the function removes the stopwords from the vocabulary and computes the stemming of the words
#
# def read_document(file) :
#     f = open(file, encoding="utf-8")
#     f2 = open("aclImdb/stopwords.txt")
#     stop = f2.read().split()
#     text = f.read()
#     f.close()
#     words = []
#     text = text.lower()
#     text = remove_punctuation(text)
#     for word in text.split():
#         if len(word) >2 and word not in stop:
#             words.append(stem(word))
#     return words


#   This variant of the function is the basic one
def read_document(file) :
    f = open(file, encoding="utf-8")
    text = f.read()
    f.close()
    words = []
    text = text.lower()
    text = remove_punctuation(text)
    for word in text.split():
        if len(word) > 2:
            words.append(word)
    return words


def write_vocabulary(voc, filename, n):
    f = open(filename, "w")
    for word, count in sorted(voc.most_common(n)):
        print(word, file = f)
    f.close()

#main

voc = clt.Counter()
voc.most_common()
for f in os.listdir("aclImdb/train/pos"):
    voc.update(read_document("aclImdb/train/pos/" + f))
for f in os.listdir("aclImdb/train/neg"):
    voc.update(read_document("aclImdb/train/neg/" + f))

write_vocabulary(voc, "vocabulary.txt", 3000)