import numpy as np
import os
from porter import stem
import random
from sklearn.model_selection import train_test_split

# Build validation dataset

def validation():
    filelist_pos = os.listdir("aclImdb/validation/pos/")
    filelist_paths = []
    val = []
    for f in filelist_pos:
        if f.split(".")[-1]=="txt":
            filelist_paths.append("aclImdb/validation/pos/"+f)
            val.append(1)

    filelist_neg = os.listdir("aclImdb/validation/neg/")
    for f in filelist_neg:
        if f.split(".")[-1]=="txt":
            filelist_paths.append("aclImdb/validation/neg/"+f)
            val.append(0)
    
    #I assumed a test set of 10%
    x_val_train, x_val_test, y_val_train, y_val_test = train_test_split(filelist_paths, val, test_size=0.1)

    documents_test_val = []
    documents_train_val = []

    for f in x_val_train:
        if f.split(".")[-1]=="txt":
            documents_train_val.append(read_document(f, voc))
    for f in x_val_test:
        if f.split(".")[-1]=="txt":
            documents_test_val.append(read_document(f, voc))


    Xv_train = np.stack(documents_train_val)
    Yv_train = np.array(y_val_train)
    Xv_test = np.stack(documents_test_val)
    Yv_test = np.array(y_val_test)
    print(Xv_test.shape, Xv_train.shape, Yv_test.shape, Yv_train.shape)
    data_train = np.concatenate([Xv_train, Yv_train[:, None]], 1)
    data_test = np.concatenate([Xv_test, Yv_test[:, None]], 1)
    np.savetxt("validation_train.txt.gz", data_train)
    np.savetxt("validation_test.txt.gz", data_test)


def load_vocabulary(filename):
    f = open(filename)
    n = 0
    voc = {}
    for w in f.read().split():
        voc[w] = n
        n += 1
    f.close()
    return voc


def remove_punctuation(text):
    punct = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"
    for p in punct:
        text = text.replace(p, " ")
    return text


def read_document(filename, voc):
    f = open(filename, encoding="utf8")
    text = f.read()
    f.close()
    text = remove_punctuation(text.lower())
    # Start with all zeros
    bow = np.zeros(len(voc))
    for w in text.split():
        # w = stem(w) # I decided not to use stem() method
        if w in voc:
            index = voc[w]
            bow[index] += 1
    return bow

# Build train dataset

voc = load_vocabulary("vocabulary.txt")
documents = []
labels = []
for f in os.listdir("aclImdb/train/pos"):
    if os.path.abspath(f).split(".")[-1]=="txt":
        documents.append(read_document("aclImdb/train/pos/" + f, voc))
        labels.append(1)
for f in os.listdir("aclImdb/train/neg"):
    if os.path.abspath(f).split(".")[-1]=="txt":
        documents.append(read_document("aclImdb/train/neg/" + f, voc))
        labels.append(0)
X = np.stack(documents)
Y = np.array(labels)
data = np.concatenate([X, Y[:, None]], 1)
np.savetxt("train.txt.gz", data)

# Build test dataset
documents = []
labels = []
for f in os.listdir("aclImdb/test/pos"):
    if os.path.abspath(f).split(".")[-1]=="txt":
        documents.append(read_document("aclImdb/test/pos/" + f, voc))
        labels.append(1)
for f in os.listdir("aclImdb/test/neg"):
    if os.path.abspath(f).split(".")[-1]=="txt":
        documents.append(read_document("aclImdb/test/neg/" + f, voc))
        labels.append(0)
Xt = np.stack(documents)
Yt = np.array(labels)
data = np.concatenate([Xt, Yt[:, None]], 1)
np.savetxt("test.txt.gz", data)