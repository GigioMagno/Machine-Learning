import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, KFold
from sklearn.metrics import classification_report


def sigmoid(z):
    return 1/(1+np.exp(-z))

def logreg_inference(X, w, b):
    z = (w @ X.T) + b
    p = sigmoid(z)
    return p

def accuracy(X, Y, w, b):
    p_hat = logreg_inference(X, w, b)
    y_hat = (p_hat > 0.5)
    accuracy = (Y == y_hat).mean()
    return accuracy, y_hat

def load_features(path_x, path_y):
    X = np.loadtxt(path_x)
    Y = np.loadtxt(path_y)
    return X, Y

X_val, Y_val = load_features("../features/X_val.txt", "../features/Y_val.txt")
model = LogisticRegression(max_iter=1000, solver='saga')

param_grid = {'C': [0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1, 3, 10, 30, 100, 300, 1000, 3000]}
kf = KFold(n_splits=5, shuffle=True)

grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=kf, n_jobs=-1, scoring='accuracy')
grid_search.fit(X_val, Y_val)

print(f"Best parameters: {grid_search.best_params_}")
print(f"Best cross-validation accuracy: {grid_search.best_score_:.4f}")

best_model = grid_search.best_estimator_

y_pred = best_model.predict(X_val)
print(classification_report(Y_val, y_pred))