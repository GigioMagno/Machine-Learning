from sklearn.linear_model import LogisticRegression
import numpy as np
import pickle

def train_model(X_train, y_train):
	model = LogisticRegression(penalty='l2', max_iter=2500, C=30)
	model.fit(X_train, y_train)
	return model

def load_features(path_x, path_y):
	X = np.loadtxt(path_x)
	Y = np.loadtxt(path_y)
	return X, Y


X_train, Y_train = load_features("../features/X_train.txt", "../features/Y_train.txt")

model = train_model(X_train, Y_train)

W = model.coef_
b = model.intercept_

print("Weights", W)
print("Bias", b)

np.savez("Parameters.npz", weights=W, bias=b)

with open("model.pkl", "wb") as f:
	pickle.dump(model, f)