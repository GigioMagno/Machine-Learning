import numpy as np
import pickle
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

def sigmoid(z):
    return 1/(1+np.exp(-z))

def logreg_inference(X, w, b):
    z = (w @ X.T) + b
    p = sigmoid(z)
    return p

def accuracy(X, Y, w, b):
    p_hat = logreg_inference(X, w, b)
    y_hat = (p_hat > 0.5)
    accuracy = (Y == y_hat).mean()
    return accuracy, y_hat

def load_features(path_x, path_y):
    X = np.loadtxt(path_x)
    Y = np.loadtxt(path_y)
    return X, Y

def evaluate_model(model, X_test, y_test):
    predictions = model.predict(X_test)
    print(classification_report(y_test, predictions))

def num_2_square(num):
    
    num = num // 13
    row = num // 8
    col = num % 8
    row_num = 8 - row
    col_char = chr(ord('A') + col)
    square = f"{col_char}{row_num}"
    return square

X_test, Y_test = load_features("../features/X_test.txt", "../features/Y_test.txt")
rows = X_test.shape[0]

ds = np.load("/Users/svitol/Desktop/MLassignment/src/Parameters.npz")
W = ds["weights"]
b = ds["bias"]

#### Question 1 ####
relevant_piece = []
num_pieces = 13
pieces = {-6:"Black King", -5:"Black Queen", -4:"Black Rook", -3:"Black Bishop", -2:"Black Knight", -1:"Black Pawn", 6:"White King", 5:"White Queen", 
        4:"White Rook", 3:"White Bishop", 2:"White Knight", 1:"White Pawn"}
Q = W[:, :-1]
P = X_test[:, :-1]
max_idx_list = []

print("Question 1")
for i in range(rows):
    masked = np.where(P[i], Q, 0)
    masked = masked.flatten()
    masked_abs = np.abs(masked)
    max_idx = np.argmax(masked_abs)
    max_idx_list.append(max_idx)            #Contains index of the piece with best weight for each chessboard
    piece = max_idx%num_pieces - 6
    if piece != 0:
        tmp = [masked_abs[max_idx], pieces[piece]]
        relevant_piece.append(tmp)          #Contains value of the weight and piece
relevant_piece = np.array(relevant_piece)
print(relevant_piece)
sorted_idx = np.argsort(relevant_piece[:,0])
sorted_matrix = relevant_piece[sorted_idx]

print("Matrix with sorted rows\n", sorted_matrix)
#unique_matrix = np.unique(sorted_matrix, axis=0)
#print("Matrix with unique rows\n", unique_matrix)

#### Question 2 ####
print("Question 2")
side_to_move_vals = W[:,-1]
print(side_to_move_vals.shape)
print(min(side_to_move_vals))
#I changed in the "test" script the values of the last 
#weights trying to set it to the opposite of the current value, 
#or set them to 0, or again, increasing its value


#### Question 3 ####
# I have to train again and test the logistic regression model in order to 
#estimate the precision and then I will compare it with the one of the complete model
X_pieces_count_train, Y_train = load_features("../features/X_pieces_count_train.txt", "../features/Y_train.txt")
X_pieces_count_test, Y_test = load_features("../features/X_pieces_count_test.txt", "../features/Y_test.txt")

model = LogisticRegression(max_iter=1000, C=50)
model.fit(X_pieces_count_train, Y_train)

W_count = model.coef_
b_count = model.intercept_
print("Question 3")

print("training performance")
#evaluate_model(model, X_pieces_count_train, Y_train)
acc_tr, _ = accuracy(X_pieces_count_train, Y_train, W_count, b_count)
print("Training accuracy: ", acc_tr)
print("Testing performance")
#evaluate_model(model, X_pieces_count_test, Y_test)
acc_te, y_hat_te = accuracy(X_pieces_count_test, Y_test, W_count, b_count)
print("Testing accuracy: ", acc_te)

print(y_hat_te.flatten().shape)
print(Y_test.shape)

confusion_mat = confusion_matrix(Y_test, y_hat_te.flatten())

plt.figure(figsize=(8, 6))
sns.heatmap(confusion_mat, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['Black', 'White'], 
            yticklabels=['Black', 'White'])
plt.xlabel('Pred')
plt.ylabel('True')
plt.title('Confusion matrix')
plt.show()



#### Question 4.a ####
print("Question 4.a")
chessboard = {}
for row in sorted_matrix:
    weight = float(row[0])
    piece = row[1]
    if piece in chessboard:
        chessboard[piece].append(weight)
    else:
        chessboard[piece] = [weight]

max_variation_pos = {}
for piece in chessboard:
    max_abs_piece = max(chessboard[piece])
    min_abs_piece = min(chessboard[piece])
    print(piece, max_abs_piece, min_abs_piece)
    if piece not in max_variation_pos:
        max_variation_pos[piece] = max_abs_piece - min_abs_piece

sorted_max_variation_pos = dict(sorted(max_variation_pos.items(), key=lambda item: item[1], reverse=True))
print(sorted_max_variation_pos) #contains the pieces and their variations in descending order

#### Question 4.b ####
print("Question 4.b")

weight_piece_pos = np.array(relevant_piece)
positions = np.array(max_idx_list)
positions = positions.reshape(-1,1)
weight_piece_pos = np.hstack((weight_piece_pos, positions))
sorted_matrix_index = np.lexsort((weight_piece_pos[:,0], weight_piece_pos[:,1]))
sorted_chessboards = weight_piece_pos[sorted_matrix_index]

data = {}
n_elem = 3

for row in sorted_chessboards:
    if row[1] in data:
        data[row[1]].add(row[2])
    else:
        data[row[1]] = set()

for x in data:
    tmp = []
    for y in range(n_elem):
        tmp.append(list(data[x])[-y-1])
    print(x, tmp)

for key in sorted_max_variation_pos:
    if key in data:
        for x in range(n_elem):
            idx_cell = list(data[key])[-x-1].astype(int)
            print(key, " best squares: ", num_2_square(idx_cell))