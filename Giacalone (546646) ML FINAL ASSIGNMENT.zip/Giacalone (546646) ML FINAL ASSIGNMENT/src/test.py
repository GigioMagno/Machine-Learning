import numpy as np
import pickle
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import precision_recall_curve
import seaborn as sns
import matplotlib.pyplot as plt

def sigmoid(z):
    return 1/(1+np.exp(-z))

def logreg_inference(X, w, b):
    z = (w @ X.T) + b
    p = sigmoid(z)
    return p

def accuracy(X, Y, w, b):
    p_hat = logreg_inference(X, w, b)
    y_hat = (p_hat > 0.5)
    accuracy = (Y == y_hat).mean()
    return accuracy, y_hat

def load_features(path_x, path_y):
    X = np.loadtxt(path_x)
    Y = np.loadtxt(path_y)
    return X, Y

def evaluate_model(model, X_test, y_test):
    predictions = model.predict(X_test)
    print(classification_report(y_test, predictions))


X_train, Y_train = load_features("../features/X_train.txt", "../features/Y_train.txt")
X_test, Y_test = load_features("../features/X_test.txt", "../features/Y_test.txt")
ds = np.load("/Users/svitol/Desktop/MLassignment/src/Parameters.npz")
W = ds["weights"]
#W[:,-1]=0 #-> used for question 2
b = ds["bias"]
print(W.shape)
print(b.shape)

print(X_train.shape)
print(Y_train.shape)
print(X_test.shape)
print(Y_test.shape)

print("Training accuracy")
tr_acc, y_hat_tr = accuracy(X_train, Y_train, W, b)
print(tr_acc)

print("Test accuracy")
te_acc, y_hat_te = accuracy(X_test, Y_test, W, b)
y_hat_te = y_hat_te.flatten()
print(te_acc)


with open("model.pkl", "rb") as f:
	model = pickle.load(f)

print("Train")
evaluate_model(model, X_train, Y_train)

print("Test")
evaluate_model(model, X_test, Y_test)

confusion_mat = confusion_matrix(Y_test, y_hat_te)

plt.figure(figsize=(8, 6))
sns.heatmap(confusion_mat, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['Black', 'White'], 
            yticklabels=['Black', 'White'])
plt.xlabel('Pred')
plt.ylabel('True')
plt.title('Confusion matrix')
plt.show()

y_prob = model.predict_proba(X_test)[:, 1]
fpr, tpr, _ = roc_curve(Y_test, y_prob)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc='lower right')
plt.show()

precision, recall, _ = precision_recall_curve(Y_test, y_prob)

plt.figure()
plt.plot(recall, precision, color='blue', lw=2)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall Curve')
plt.show()