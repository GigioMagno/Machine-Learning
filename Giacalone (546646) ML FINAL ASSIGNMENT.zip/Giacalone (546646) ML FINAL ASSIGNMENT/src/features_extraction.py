import os
import numpy as np

def parse_fen_board(fen):
	fen = fen.replace("/" , "") 
	for i in range(1, 9):
		fen = fen.replace(str(i), "*" * i)
		codes = map("kqrbnp*PNBRQK".index , fen)
	return [x - 6 for x in codes]

def read_dataset(path):
    # encoding rule: black -> 0, white -> 1
    encoding = {"w": 1, "b": 0}
    num_cells = 64
    pieces = 13
    num_pieces = [] #left value is the number of pieces for white, right value is the number of pieces for black -> used for question 3
    rows = []
    Y = []

    for line in open(path, "r"):
        line = line.strip("\n")
        line = line.split(" ")

        black_pieces_count = 0
        white_pieces_count = 0
        
        row = parse_fen_board(line[0])
        row_encoded = np.zeros(num_cells * pieces)
        for j in range(num_cells):
            piece = row[j]
            if piece != 0:  # if cell is not empty
                if piece < 0:
                    black_pieces_count+=1
                elif piece > 0:
                    white_pieces_count+=1

                cod = piece + 6  # move the pieces from -6 to 6 up to 0 12
                row_encoded[j * pieces + cod] = 1
        num_pieces.append([white_pieces_count, black_pieces_count])
        
        row_encoded = np.append(row_encoded, encoding[line[1]]) #-> add the side to move variable
        rows.append(row_encoded)
        Y.append(encoding[line[2]])

    X_pieces_count = np.array(num_pieces)   #Contains pieces white - black
    X = np.array(rows)  # onehot encoded X matrix
    Y = np.array(Y)     # labels

    return X, Y, X_pieces_count

def save_matrices(X, Y, x_filename='X.txt', y_filename='Y.txt'):

    np.savetxt(x_filename, X, fmt='%d', delimiter=' ')
    
    np.savetxt(y_filename, Y, fmt='%d')

# MAIN #

X_train, Y_train, X_pieces_count_train = read_dataset("/Users/svitol/Desktop/MLassignment/dataset/train.txt")
X_val, Y_val, _ = read_dataset("/Users/svitol/Desktop/MLassignment/dataset/validation.txt")
X_test, Y_test, X_pieces_count_test = read_dataset("/Users/svitol/Desktop/MLassignment/dataset/test.txt")
save_matrices(X_train, Y_train, x_filename="../features/X_train.txt", y_filename="../features/Y_train.txt")
save_matrices(X_test, Y_test, x_filename="../features/X_test.txt", y_filename="../features/Y_test.txt")
save_matrices(X_test, Y_test, x_filename="../features/X_val.txt", y_filename="../features/Y_val.txt")

np.savetxt("../features/X_pieces_count_train.txt", X_pieces_count_train, fmt='%d')
np.savetxt("../features/X_pieces_count_test.txt", X_pieces_count_test, fmt='%d')