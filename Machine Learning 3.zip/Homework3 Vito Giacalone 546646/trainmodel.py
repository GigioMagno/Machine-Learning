import numpy as np
import pvml
import matplotlib.pyplot as plt
import time


def show_sample(id):
    image = Xtrain[id, :].reshape(20, 80)
    plt.imshow(image)
    plt.colorbar()
    plt.show()

def whitening(Xtrain, Xtest):
    mu = Xtrain.mean(0)
    sigma = np.cov(Xtrain.T)
    evals, evecs = np.linalg.eigh(sigma)
    w = evecs / np.sqrt(evals)
    Xtrain = (Xtrain - mu) @ w
    Xtest = (Xtest - mu) @ w
    return Xtrain, Xtest

def minmax_norm(Xtrain, Xtest):
    xmin = Xtrain.min(0)
    xmax = Xtrain.max(0)
    Xtrain = (Xtrain - xmin) / (xmax - xmin)
    Xtest = (Xtest - xmin) / (xmax - xmin)
    return Xtrain, Xtest

def mean_var_norm(Xtrain, Xtest):
    mu = Xtrain.mean(0)
    std = Xtrain.std(0)
    Xtrain = (Xtrain - mu) / std
    Xtest = (Xtest - mu) / std
    return Xtrain, Xtest

def maxabs_norm(Xtrain, Xtest):
    amax = np.abs(Xtrain).max(0)
    Xtrain = Xtrain / amax
    Xtest = Xtest / amax
    return Xtrain, Xtest

def L1_norm(X):
    q = np.abs(X).sum(1, keepdims=True)
    q = np.maximum(q, 1e-15)
    X = X / q
    return X

def L2_norm(X):
    q = np.sqrt((X ** 2).sum(1, keepdims=True))
    q = np.maximum(q, 1e-15)
    X = X / q
    return X

def accuracy(net, X, Y):
    labels, probs = net.inference(X)
    acc = (labels == Y).mean()
    return acc * 100


# Reading classes
words = open("data/classes.txt").read().split()

# Load dataset
data = np.load("data/train.npz")
Xtrain = data["arr_0"]
Ytrain = data["arr_1"]
data = np.load("data/test.npz")
Xtest = data["arr_0"]
Ytest = data["arr_1"]
t1 = time.time()

# SHOW SAMPLE BEFORE NORMALIZATION
# before = Xtrain[0, :].reshape(20, 80)
# plt.subplot(1,2,1)
# plt.imshow(before)
# plt.title("Data before normalization")
# plt.colorbar()

# APPLY NORMALIZATION
# Xtrain, Xtest = mean_var_norm(Xtrain, Xtest)
# Xtrain, Xtest = minmax_norm(Xtrain, Xtest)
# Xtrain, Xtest = whitening(Xtrain, Xtest)
# Xtrain = L1_norm(Xtrain)
# Xtest = L1_norm(Xtest)
Xtrain = L2_norm(Xtrain)
Xtest = L2_norm(Xtest)

# SHOW SAMPLE AFTER NORMALIZATION
# after = Xtrain[0, :].reshape(20, 80)
# plt.subplot(1,2,2)
# plt.imshow(after)
# plt.title("Data after normalization")
# plt.colorbar()
# plt.show()


# CREATE AND TRAIN THE MULTI-LAYER PERCEPTRON
network = pvml.MLP([1600,3150,3150, 35])
m = Ytrain.size
train_accs = []
test_accs = []
epochs = []
batch_size = 256
print("batch size:", batch_size)
for epoch in range(25):
    network.train(Xtrain, Ytrain, 0.001, steps=m // batch_size, batch=batch_size)
    train_accuracies = accuracy(network, Xtrain, Ytrain)
    test_acc = accuracy(network, Xtest, Ytest)
    print("epoch: ", epoch, "train acc: ", train_accuracies, "test acc: ", test_acc)
    train_accs.append(train_accuracies)
    test_accs.append(test_acc)
    epochs.append(epoch)
t2 = time.time()
print("training time:", (int)((t2 - t1) / 60), "mins, ", (t2 - t1) % 60, "secs")
plt.clf()
plt.plot(epochs, train_accs)
plt.plot(epochs, test_accs)
plt.xlabel("epochs")
plt.ylabel("accuracies (%)")
plt.legend(["train", "test"])
plt.show()

# SAVE THE MODEL TO DISK
network.save("mlp.npz")
