import numpy as np
import pvml
import matplotlib.pyplot as plt

def whitening(Xtrain, Xtest):
    mu = Xtrain.mean(0)
    sigma = np.cov(Xtrain.T)
    evals, evecs = np.linalg.eigh(sigma)
    w = evecs / np.sqrt(evals)
    Xtrain = (Xtrain - mu) @ w
    Xtest = (Xtest - mu) @ w
    return Xtrain, Xtest

def minmax_norm(Xtrain, Xtest):
    xmin = Xtrain.min(0)
    xmax = Xtrain.max(0)
    Xtrain = (Xtrain - xmin) / (xmax - xmin)
    Xtest = (Xtest - xmin) / (xmax - xmin)
    return Xtrain, Xtest

def mean_var_norm(Xtrain, Xtest):
    mu = Xtrain.mean(0)
    std = Xtrain.std(0)
    Xtrain = (Xtrain - mu) / std
    Xtest = (Xtest - mu) / std
    return Xtrain, Xtest

def maxabs_norm(Xtrain, Xtest):
    amax = np.abs(Xtrain).max(0)
    Xtrain = Xtrain / amax
    Xtest = Xtest / amax
    return Xtrain, Xtest

def L1_norm(X):
    q = np.abs(X).sum(1, keepdims=True)
    q = np.maximum(q, 1e-15)
    X = X / q
    return X

def L2_norm(X):
    q = np.sqrt((X ** 2).sum(1, keepdims=True))
    q = np.maximum(q, 1e-15)
    X = X / q
    return X

def accuracy(neural_network, X, Y):
    labels, probs = neural_network.inference(X)
    acc = (labels == Y).mean()
    return acc * 100

def display_weights(network):
    w = network.weights[0]
    maxval = np.abs(w).max()
    for class_ in range(35):
        plt.subplot(5, 7, class_ + 1)
        plt.imshow(w[:, class_].reshape(20, 80), cmap="seismic", vmin=-maxval, vmax=maxval)
        plt.title(words[class_])
    plt.show()

def disp_confusion(Y, predictions):
    num_classes = Y.max() + 1

    cm = np.empty((num_classes, num_classes))

    for class_ in range(num_classes):
        sel = (Y == class_).nonzero()
        counts = np.bincount(predictions[sel], minlength=num_classes)
        cm[class_, :] = 100 * counts / max(1, counts.sum())

    plt.figure(3)
    plt.clf()
    plt.imshow(cm, vmin=0, vmax=100, cmap=plt.cm.Blues)
    
    for i in range(num_classes):
        for j in range(num_classes):
            
            colour = ("black" if cm[i, j] < 75 else "white")
            txt = "{:1d}".format(int(cm[i, j]), ha="center", va="center")
            plt.text(j - 0.25, i + 0.1, txt, color=colour)
    plt.title("Confusion matrix")

words = open("data/classes.txt").read().split()

# Loading datasets
data = np.load("data/train.npz")
Xtrain = data["arr_0"]
Ytrain = data["arr_1"]

data = np.load("data/test.npz")
Xtest = data["arr_0"]
Ytest = data["arr_1"]

#Normalize the data
Xtrain = L2_norm(Xtrain)
Xtest = L2_norm(Xtest)

#loading the weights
neural_network = pvml.MLP.load("mlp.npz")
display_weights(neural_network)

predictions, probs = neural_network.inference(Xtest)
disp_confusion(Ytest, predictions)
plt.show()
 

# print(words[10])
# print(words[30])
# print(words[15])
