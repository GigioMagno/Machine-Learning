import numpy as np

def sigmoid(z):
	return 1/(1+np.exp(-z))

def logreg_inference(X, w, b):
	z = (X @ w) + b
	p = sigmoid(z)
	return p

def cross_entropy(Y, P):
	ce = (-Y * np.log(P) - (1-Y) * np.log(1-P)).mean()
	return ce

def read_Dataset(filename):
	ds = np.loadtxt(filename)
	X = ds[:, :-1]
	Y = ds[:,-1]
	return X, Y

def accuracy(X, Y, w, b):
	p_hat = logreg_inference(X, w, b)
	y_hat = (p_hat > 0.5)
	accuracy = (Y == y_hat).mean()
	return accuracy
