import numpy as np
import matplotlib.pyplot as plt
import sys
sys.path.append('../logistic_regression/')
import logregr as lr


def logregr_train(filename):
	
	X_train, Y  = lr.read_Dataset(filename)
	w = np.zeros(X_train.shape[1])
	b = 0
	learning_rate = 0.001

	steps = []
	losses = []

	for step in range(1000000):
	
		P = lr.logreg_inference(X_train, w, b)
		loss = lr.cross_entropy(Y, P)

		if step % 1000 == 0:
				
			steps.append(step)
			losses.append(loss)
			#print("[", step, loss, "]")

		grad_w = (X_train.T @ (P - Y))/X_train.shape[0]
		grad_b = (P - Y).mean()
		w -= learning_rate*grad_w
		b -= learning_rate*grad_b

	accuracy = lr.accuracy(X_train, Y, w, b)

	return w, b, steps, losses, accuracy
