import numpy as np
import matplotlib.pyplot as plt
import sys
sys.path.append('../logistic_regression/')
import logregr as lr


def logregr_test(filename_dataset, w, b):
	
	X_test, Y = lr.read_Dataset(filename_dataset)

	maxidx = lr.logreg_inference(X_test, w, b).argmax()
	minidx = lr.logreg_inference(X_test, w, b).argmin()


	accuracy = lr.accuracy(X_test, Y, w, b)

	return accuracy, X_test[maxidx,:], X_test[minidx,:]
