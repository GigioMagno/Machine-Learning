import sys
sys.path.append('../training/')
sys.path.append('../testing/')
sys.path.append('../logistic_regression/')
import train as tr
import testing as te
import logregr as lr
import numpy as np
import matplotlib.pyplot as plt

#Analyze the model

#Read my data in txtfile
my_X = np.loadtxt('mydata.txt')
print('myx ', my_X)
#Computing the weights
w, b, steps, losses, accuracy_training = tr.logregr_train('../training/titanic-train.txt')

#Probability to survive
prob_survive = lr.logreg_inference(my_X, w, b)
print('Probability to survive: ', prob_survive)
print('accuracy training: ', accuracy_training)
print('Weights: ', w, b)

accuracy_test, most_prob, least_prob = te.logregr_test('../testing/titanic-test.txt', w, b)
print('Most probable: ', most_prob, '(', lr.logreg_inference(most_prob, w, b), ')')
print('Least probable: ', least_prob, '(', lr.logreg_inference(least_prob, w, b), ')')

#Plot the classes according to the most influential features
data = np.loadtxt('../testing/titanic-test.txt')
X_test = data[:,:-1]
Y_test = data[:, -1]
plt.xlabel("Class")
plt.ylabel("Sex")
plt.scatter(X_test[:,0]+0.1 * np.random.randn(data.shape[0]), X_test[:,1]+ 0.1 * np.random.randn(data.shape[0]))
plt.show()

#Evaluate the model
print('Test accuracy: ', accuracy_test)

plt.plot(steps, losses)
plt.xlabel("Steps")
plt.ylabel("Loss - Cross entropy")
plt.axhline(y=0.428, color='g', linestyle='-')
plt.show()





















